<?php
$s_ip = $_SERVER['HTTP_CLIENT_IP']
? $_SERVER['HTTP_CLIENT_IP']
: ($_SERVER['HTTP_X_FORWARDED_FOR']
? $_SERVER['HTTP_X_FORWARDED_FOR']
: $_SERVER['REMOTE_ADDR']);

$s_user = 'root';
$s_pass = 'xxxx';

$file = file_get_contents("http://$s_ip:82/server/online_app.json");
$data = json_decode($file);
if ($data != NULL) {
	$onlines = $data[0]->onlines;
	$limite = $data[0]->limite;
}

include('Net/SSH2.php');
$ssh = new Net_SSH2("$s_ip");
if (!$ssh->login("$s_user", "$s_pass")) {
	echo 'fail';
} elseif ($onlines < 1 ) {
	echo 'success'.$onlines;
  $ssh->exec("curl -X POST -H 'Authorization: Bearer Vmdle52oxVPhVGEThBE0zLbMKwoxeim5ngbjrPVMquB' -F 'message='' \n
⚠️คนออนไลน์ $onlines คน
$s_ip - (แก้ไขแล้ว)
''' https://notify-api.line.me/api/notify > /dev/null 2>&1");
	$ssh->getServerPublicHostKey();
	$ssh->exec("reiniciarservicos");

} else {

	echo $s_ip.' ออนไลน์ : '.$onlines.' คน';
$ssh->exec("curl -X POST -H 'Authorization: Bearer Vmdle52oxVPhVGEThBE0zLbMKwoxeim5ngbjrPVMquB' -F 'message='' \n
✅คนออนไลน์ $onlines คน
$s_ip - (เซิร์ฟปกติ)
''' https://notify-api.line.me/api/notify > /dev/null 2>&1");
}
?>